import Solution
Solution.CharacterFrequency()
