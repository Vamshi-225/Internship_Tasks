# Q1. Find the Frequency of Each Word in a Sentence
# expected output : {'python': 2, 'is': 2, 'easy': 1, 'and': 1, 'powerful': 1}

def WordFrequency(Sentence):
    freq={}
    for i in Sentence:
        if i in freq:
            freq[i]+=1
        else:
            freq[i]=1
    return freq
Sentence=input("Enter The String:")
Words=Sentence.split()
x=WordFrequency(Words)
print(x)

#Q2. Find the Frequency of Each Character in a Word
# expected output : {'b': 1, 'a': 3, 'n': 2}
def CharacterFrequency(Character):
    freq={}
    for i in Character:
        if i in freq:
            freq[i]+=1
        else:
            freq[i]=1
    return freq
Character=input("Enter The String:")
w=CharacterFrequency(Character)
print(w)

#Q3. Find the First Non-Repeating Character in a Word
#Expected Output:w

def NonRepeatingCharacter(String):
    freq={}
    for i in String:
        if i in freq:
            freq[i]+=1
        else:
            freq[i]=1
    for i in String:
        if freq[i]==1:
            return i
    return None
String=input("Enter The String:")
s=NonRepeatingCharacter(String)
print(s)


#Q4. Check Whether Two Strings Are Anagrams
'''Example Input:
s1 = "listen"
s2 = "silent"
Expected Output:
True'''

def AnagramCheck(str1, str2):
    if sorted(str1) == sorted(str2):
        return True
    else:
        return False

str1 = input("Enter first string: ")
str2 = input("Enter second string: ")

print(AnagramCheck(str1, str2))

#Q5. Find the First Repeating Character in a String
'''Example Input:
programming
Expected Output:
r'''


def FirstRepeatingCharacter(string):
    freq = {}

    for i in string:
        if i in freq:
            return i
        else:
            freq[i] = 1

    return None

string = input("Enter the string: ")
print(FirstRepeatingCharacter(string))


#Q6. Move All Zeros to the End of a List

def ZerosEndofList(list1):
    l=[]
    zeros=[]
    for i in list1:
        if i==0:
            zeros.append(i)
        else:
            l.append(i)
    return l+zeros
list1=list(map(int,input("Enter The List elements").split()))
a=ZerosEndofList(list1)
print(a)

#Q7. Find the Second Highest Distinct Number in a List
def SecondHighest(Array):
    largest=Array[0]
    second=float('-inf')
    for i in Array:
        if i>largest:
            second=largest
            largest=i
        elif i>second and i<largest:
            second=i
    return second
Array=list(map(int,input("Enter The List elements").split()))
a=SecondHighest(Array)
print(a)


#Q9. Find the Missing Number from 1 to N
def MissingNumber(array):
    n=len(array)+1
    s=n*(n+1)//2
    a=sum(array)
    return s-a
array=list(map(int,input("Enter The List elements").split()))
a=MissingNumber(array)
print(a)

#Q10. Find Two Numbers Whose Sum Equals a Target
def SumEqualsTarget(array,target):
    n=len(array)
    for i in range(0,n):
        for j in range(i+1,n):
            if array[i]+array[j]==target:
                return i,j
    return None
array=list(map(int,input("Enter The List elements").split()))
c=SumEqualsTarget(array,6)
print(c)

#Q11. Find the Number Closest to Zero

def ClosestToZero(array):
    closest = array[0]

    for i in array:
        if abs(i) < abs(closest):
            closest = i

    return closest

array = list(map(int, input("Enter the list elements: ").split()))
print(ClosestToZero(array))


#Q12. Find Common Elements Between Two Lists

def CommonElements(array1, array2):
    common = []

    for i in array1:
        if i in array2 and i not in common:
            common.append(i)

    return common

array1 = list(map(int, input("Enter the first list: ").split()))
array2 = list(map(int, input("Enter the second list: ").split()))

print(CommonElements(array1, array2))


#Q13. Rotate a List to the Right by K Positions

def RotateList(array, k):
    n = len(array)
    k = k % n

    return array[-k:] + array[:-k]

array = list(map(int, input("Enter the list elements: ").split()))
k = int(input("Enter k: "))

print(RotateList(array, k))


#Q14. Find the Maximum Sum of Two Consecutive Elements

def MaximumSum(array):
    largest = array[0] + array[1]

    for i in range(1, len(array) - 1):
        total = array[i] + array[i + 1]

        if total > largest:
            largest = total

    return largest

array = list(map(int, input("Enter the list elements: ").split()))
print(MaximumSum(array))


# Q15. Find All Pairs of Numbers Whose Sum Equals a Target

def SumEqualsTarget(array, target):
    n = len(array)
    pairs = []

    for i in range(n):
        for j in range(i + 1, n):
            if array[i] + array[j] == target:
                pairs.append((array[i], array[j]))

    return pairs

array = list(map(int, input("Enter the list elements: ").split()))
target = int(input("Enter the target: "))

print(SumEqualsTarget(array, target))

    




    




    




