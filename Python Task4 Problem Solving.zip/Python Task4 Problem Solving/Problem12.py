def average(array):
    # your code goes here
    arr=set(array)
    return round(sum(arr)/len(arr),3)

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)