if __name__ == '__main__':
    a = int(input())
    b = int(input())
normal_division=a/b
floor_division=a//b
print(floor_division)
print(normal_division)