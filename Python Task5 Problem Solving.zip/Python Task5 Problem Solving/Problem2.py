#Q2
def split_and_join(line):
    # write your code here
    word=line.split()
    new='-'.join(word)
    return new

if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)