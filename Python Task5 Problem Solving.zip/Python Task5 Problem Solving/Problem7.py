#Q7
M=int(input())
A=set(map(int,input().split()))

N=int(input())
B=set(map(int,input().split()))

Symmetric_Difference=A^B
for i in sorted(Symmetric_Difference):
    print(i)
