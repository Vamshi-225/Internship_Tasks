X=int(input())
A=set(map(int,input().split()))
Y=int(input())
B=set(map(int,input().split()))
Union=A|B
print(len(Union))