X=int(input())
A=set(map(int,input().split()))

Y=int(input())
B=set(map(int,input().split()))
Intersection=A&B
print(len(Intersection))