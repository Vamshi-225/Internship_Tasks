
X=int(input())
A=set(map(int,input().split()))

Y=int(input())
B=set(map(int,input().split()))

Difference=A-B
print(len(Difference))
